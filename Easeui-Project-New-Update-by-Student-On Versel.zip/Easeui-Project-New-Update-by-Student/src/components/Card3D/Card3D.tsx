import React, { useRef, useState } from "react";
import { cva, type VariantProps } from "class-variance-authority";
import { cn } from "@/libs/utils";
import gsap from "gsap";

const card3DVariants = cva(
  "relative rounded-xl shadow-lg select-none cursor-pointer",
  {
    variants: {
      variant: {
        light: "bg-white text-gray-900",
        dark: "bg-slate-900 text-white",
      },
      size: {
        sm: "w-56 h-72",
        md: "w-72 h-96",
        lg: "w-80 h-[28rem]",
      },
    },
    defaultVariants: { variant: "light", size: "md" },
  }
);

export interface Card3DProps
  extends Omit<React.HTMLAttributes<HTMLDivElement>, "children">,
    VariantProps<typeof card3DVariants> {
  title?: string;
  description?: string;
  image?: string;
  maxTilt?: number;
  // if given, clicking the card flips it over and reveals this on the back
  back?: React.ReactNode;
}

const Card3D = React.forwardRef<HTMLDivElement, Card3DProps>(
  (
    { title, description, image, variant, size, maxTilt = 12, back, className, ...props },
    ref
  ) => {
    const wrapperRef = useRef<HTMLDivElement | null>(null); // handles the tilt
    const flipRef = useRef<HTMLDivElement | null>(null); // handles the flip rotation
    const shineRef = useRef<HTMLDivElement | null>(null);
    const [flipped, setFlipped] = useState(false);

    const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
      const el = wrapperRef.current;
      if (!el) return;
      const rect = el.getBoundingClientRect();
      const x = e.clientX - rect.left;
      const y = e.clientY - rect.top;
      const rotateY = ((x - rect.width / 2) / (rect.width / 2)) * maxTilt;
      const rotateX = -((y - rect.height / 2) / (rect.height / 2)) * maxTilt;

      gsap.to(el, {
        rotateX,
        rotateY,
        transformPerspective: 900,
        duration: 0.3,
        ease: "power2.out",
      });

      // the holographic shine follows the cursor diagonally across the card
      if (shineRef.current) {
        const percentX = (x / rect.width) * 100;
        const percentY = (y / rect.height) * 100;
        gsap.to(shineRef.current, {
          opacity: 0.35,
          backgroundPosition: `${percentX}% ${percentY}%`,
          duration: 0.2,
          ease: "power2.out",
        });
      }
    };

    const handleMouseLeave = () => {
      const el = wrapperRef.current;
      if (!el) return;
      gsap.to(el, { rotateX: 0, rotateY: 0, duration: 0.6, ease: "elastic.out(1, 0.4)" });
      if (shineRef.current) gsap.to(shineRef.current, { opacity: 0, duration: 0.4 });
    };

    const handleClick = () => {
      if (!back) return; // nothing to flip to, so plain card
      const next = !flipped;
      setFlipped(next);
      if (flipRef.current) {
        gsap.to(flipRef.current, {
          rotateY: next ? 180 : 0,
          duration: 0.6,
          ease: "power2.inOut",
        });
      }
    };

    return (
      <div
        ref={(node) => {
          wrapperRef.current = node;
          if (typeof ref === "function") ref(node as HTMLDivElement);
          else if (ref) ref.current = node as HTMLDivElement;
        }}
        onMouseMove={handleMouseMove}
        onMouseLeave={handleMouseLeave}
        onClick={handleClick}
        className={cn(card3DVariants({ variant, size }), "overflow-visible", className)}
        style={{ transformStyle: "preserve-3d" }}
        {...props}
      >
        {/* the actual flipping surface, kept separate from the tilt wrapper */}
        <div
          ref={flipRef}
          className="relative h-full w-full rounded-xl overflow-hidden"
          style={{ transformStyle: "preserve-3d" }}
        >
          {/* front face */}
          <div
            className="absolute inset-0"
            style={{ backfaceVisibility: "hidden" }}
          >
            {image && (
              <div className="absolute inset-0">
                <img src={image} alt={title || "Card"} className="h-full w-full object-cover" />
                <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/10 to-transparent" />
              </div>
            )}

            {/* holographic shine sweep, follows the cursor */}
            <div
              ref={shineRef}
              className="pointer-events-none absolute inset-0 opacity-0"
              style={{
                background:
                  "radial-gradient(circle at center, rgba(255,255,255,0.65), transparent 60%)",
                backgroundSize: "160% 160%",
              }}
            />

            <div className="relative z-10 flex h-full flex-col justify-end p-5">
              {title && <h3 className="text-lg font-semibold text-white drop-shadow">{title}</h3>}
              {description && (
                <p className="mt-1 text-sm text-white/80 drop-shadow">{description}</p>
              )}
              {back && (
                <span className="mt-2 text-xs uppercase tracking-wide text-white/60">
                  Click to flip
                </span>
              )}
            </div>
          </div>

          {/* back face - only rendered if `back` content was given */}
          {back && (
            <div
              className="absolute inset-0 flex items-center justify-center p-5"
              style={{
                backfaceVisibility: "hidden",
                transform: "rotateY(180deg)",
              }}
            >
              <div
                className={cn(
                  "h-full w-full rounded-xl flex items-center justify-center text-center",
                  variant === "dark" ? "bg-slate-800 text-white" : "bg-gray-50 text-gray-900"
                )}
              >
                {back}
              </div>
            </div>
          )}
        </div>
      </div>
    );
  }
);

Card3D.displayName = "Card3D";
// eslint-disable-next-line react-refresh/only-export-components
export { Card3D, card3DVariants };
