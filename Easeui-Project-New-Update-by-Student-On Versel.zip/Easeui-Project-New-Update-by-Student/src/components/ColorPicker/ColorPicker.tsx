import { useState, useRef, useEffect } from "react";
import { cva, type VariantProps } from "class-variance-authority";
import { cn } from "@/libs/utils";
import gsap from "gsap";



const triggerVariants = cva(
  "flex items-center gap-2 rounded-md border px-3 py-2 text-sm transition-colors cursor-pointer",
  {
    variants: {
      variant: {
        light: "bg-white border-gray-300 text-gray-800 hover:bg-gray-50",
        dark: "bg-slate-900 border-slate-700 text-white hover:bg-slate-800",
      },
    },
    defaultVariants: { variant: "light" },
  }
);

const DEFAULT_SWATCHES = [
  "#ef4444",
  "#f97316",
  "#f59e0b",
  "#eab308",
  "#84cc16",
  "#22c55e",
  "#10b981",
  "#06b6d4",
  "#3b82f6",
  "#6366f1",
  "#8b5cf6",
  "#ec4899",
  "#111827",
  "#6b7280",
  "#ffffff",
];

export interface ColorPickerProps extends VariantProps<typeof triggerVariants> {
  value?: string;
  defaultValue?: string;
  onChange?: (color: string) => void;
  swatches?: string[];
  label?: string;
  className?: string;
  /** Speak "Pick me, pick me!" out loud while closed. Default true. */
  enableVoice?: boolean;
  /** Seconds between nudge cycles while closed. Default 1.5 (fast/insistent). */
  nudgeDelaySec?: number;
}

/** Speaks a short phrase using the browser's SpeechSynthesis API, if available. */
function speak(text: string) {
  if (typeof window === "undefined") return;
  if (!("speechSynthesis" in window)) return;

  try {
    // Cancel anything already queued so lines never overlap/stack up.
    window.speechSynthesis.cancel();

    const utterance = new SpeechSynthesisUtterance(text);
    utterance.rate = 1.1; // slightly quick, energetic
    utterance.pitch = 1.15; // slightly higher, playful/pleading tone
    utterance.volume = 1;

    window.speechSynthesis.speak(utterance);
  } catch {
    // Fails silently — voice is a nice-to-have, never block the UI on it.
  }
}

const ColorPicker = ({
  value,
  defaultValue = "#6366f1",
  onChange,
  swatches = DEFAULT_SWATCHES,
  variant = "light",
  label = "Color",
  className,
  enableVoice = true,
  nudgeDelaySec = 1.5,
}: ColorPickerProps) => {
  const [internalColor, setInternalColor] = useState(defaultValue);
  const [open, setOpen] = useState(false);
  const panelRef = useRef<HTMLDivElement | null>(null);
  const wrapperRef = useRef<HTMLDivElement | null>(null);
  const triggerRef = useRef<HTMLButtonElement | null>(null);
  const bubbleRef = useRef<HTMLDivElement | null>(null);

  const color = value ?? internalColor;

  const setColor = (next: string) => {
    if (value === undefined) setInternalColor(next);
    onChange?.(next);
  };

  // Open animation for the popover panel.
  useEffect(() => {
    if (open && panelRef.current) {
      gsap.fromTo(
        panelRef.current,
        { opacity: 0, y: -6, scale: 0.97 },
        { opacity: 1, y: 0, scale: 1, duration: 0.15, ease: "power2.out" }
      );
    }
  }, [open]);

  // "Pick me, pick me!" nudge loop — wiggle + speech bubble + spoken voice.
  // Runs on a short repeating timeline while the picker is closed, and stops
  // completely (timeline killed + speech cancelled) as soon as it opens or
  // the component unmounts, so it never talks over the user or itself.
  useEffect(() => {
    if (open) {
      // Make sure nothing keeps talking after the panel opens.
      if (typeof window !== "undefined" && "speechSynthesis" in window) {
        window.speechSynthesis.cancel();
      }
      return;
    }

    const tl = gsap.timeline({ repeat: -1, repeatDelay: nudgeDelaySec });

    tl.to(triggerRef.current, {
      rotate: -8,
      duration: 0.1,
      ease: "power1.inOut",
    })
      .to(triggerRef.current, { rotate: 8, duration: 0.1, ease: "power1.inOut" })
      .to(triggerRef.current, { rotate: -6, duration: 0.1, ease: "power1.inOut" })
      .to(triggerRef.current, { rotate: 0, duration: 0.1, ease: "power1.inOut" })
      .fromTo(
        bubbleRef.current,
        { opacity: 0, y: 4, scale: 0.8 },
        { opacity: 1, y: 0, scale: 1, duration: 0.2, ease: "back.out(2)" },
        "-=0.1"
      )
      .call(() => {
        if (enableVoice) speak("Pick me, pick me!");
      })
      .to(bubbleRef.current, { opacity: 0, y: -4, duration: 0.2, delay: 0.9 });

    return () => {
      tl.kill();
      if (typeof window !== "undefined" && "speechSynthesis" in window) {
        window.speechSynthesis.cancel();
      }
    };
  }, [open, enableVoice, nudgeDelaySec]);

  // Close the popover on outside click.
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (
        wrapperRef.current &&
        !wrapperRef.current.contains(e.target as Node)
      ) {
        setOpen(false);
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  return (
    <div className="relative inline-block" ref={wrapperRef}>
      {/* Speech bubble — hidden by default (opacity 0), gsap fades it in/out
          in sync with the wiggle + spoken voice line. Finger points DOWN
          (👇) toward the trigger, since the popover panel opens below it. */}
      {!open && (
        <div
          ref={bubbleRef}
          className="absolute -top-9 left-1/2 -translate-x-1/2 whitespace-nowrap rounded-full bg-slate-900 px-3 py-1 text-xs text-white opacity-0 pointer-events-none"
        >
          Pick me, pick me! 👇
          <span className="absolute left-1/2 top-full -translate-x-1/2 border-4 border-transparent border-t-slate-900" />
        </div>
      )}

      <button
        ref={triggerRef}
        type="button"
        onClick={() => setOpen((o) => !o)}
        className={cn(triggerVariants({ variant }), className)}
      >
        <span
          className="h-4 w-4 rounded-full border border-black/10"
          style={{ backgroundColor: color }}
        />
        <span className="font-mono">{color}</span>
      </button>

      {open && (
        <div
          ref={panelRef}
          className="absolute z-50 mt-2 w-56 rounded-lg border border-gray-200 bg-white p-3 shadow-xl"
        >
          {label && (
            <p className="mb-2 text-xs font-medium text-gray-500">{label}</p>
          )}

          <div className="grid grid-cols-5 gap-2 mb-3">
            {swatches.map((s) => (
              <button
                key={s}
                type="button"
                onClick={() => setColor(s)}
                aria-label={s}
                className={cn(
                  "h-7 w-7 rounded-full border transition-transform hover:scale-110",
                  color.toLowerCase() === s.toLowerCase()
                    ? "ring-2 ring-offset-2 ring-indigo-500 border-transparent"
                    : "border-black/10"
                )}
                style={{ backgroundColor: s }}
              />
            ))}
          </div>

          <div className="flex items-center gap-2">
            <input
              type="color"
              value={color}
              onChange={(e) => setColor(e.target.value)}
              className="h-8 w-8 cursor-pointer rounded border border-gray-200 p-0"
            />
            <input
              type="text"
              value={color}
              onChange={(e) => setColor(e.target.value)}
              className="w-full rounded-md border border-gray-300 px-2 py-1 text-sm font-mono focus:outline-none focus:ring-1 focus:ring-indigo-500"
            />
          </div>
        </div>
      )}
    </div>
  );
};

ColorPicker.displayName = "ColorPicker";
// eslint-disable-next-line react-refresh/only-export-components
export { ColorPicker, triggerVariants as colorPickerTriggerVariants };
