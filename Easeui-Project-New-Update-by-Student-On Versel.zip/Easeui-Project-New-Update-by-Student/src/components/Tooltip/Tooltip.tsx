import React, { useState, useRef } from "react";
import { cva, type VariantProps } from "class-variance-authority";
import { cn } from "@/libs/utils";
import gsap from "gsap";

// same idea as cardVariants in Card.tsx - just styling for the tooltip bubble
const tooltipVariants = cva(
  "absolute z-50 px-3 py-1.5 rounded-md text-xs whitespace-nowrap shadow-md",
  {
    variants: {
      variant: {
        dark: "bg-slate-900 text-white",
        light: "bg-white text-gray-800 border border-gray-300",
      },
      // where the tooltip shows up relative to the child element
      position: {
        top: "bottom-full left-1/2 -translate-x-1/2 mb-2",
        bottom: "top-full left-1/2 -translate-x-1/2 mt-2",
      },
    },
    defaultVariants: {
      variant: "dark",
      position: "top",
    },
  }
);

interface TooltipProps extends VariantProps<typeof tooltipVariants> {
  children: React.ReactNode; // the element the tooltip is attached to
  text: string; // tooltip text
  className?: string;
}

const Tooltip = ({ children, text, variant, position, className }: TooltipProps) => {
  const [show, setShow] = useState(false);
  const bubbleRef = useRef<HTMLDivElement | null>(null);

  // small helper - runs a quick scale+fade in, same feel Card.tsx uses on hover
  const playEnter = (node: HTMLDivElement | null) => {
    if (!node) return;
    gsap.fromTo(
      node,
      { opacity: 0, scale: 0.85, y: position === "bottom" ? -4 : 4 },
      { opacity: 1, scale: 1, y: 0, duration: 0.18, ease: "back.out(2)" }
    );
  };

  return (
    <div
      className="relative inline-block"
      onMouseEnter={() => setShow(true)}
      onMouseLeave={() => setShow(false)}
    >
      {children}

      {show && (
        <div
          ref={(node) => {
            bubbleRef.current = node;
            playEnter(node);
          }}
          className={cn(tooltipVariants({ variant, position }), className)}
        >
          {text}
        </div>
      )}
    </div>
  );
};

Tooltip.displayName = "Tooltip";
// eslint-disable-next-line react-refresh/only-export-components
export { Tooltip, tooltipVariants };
