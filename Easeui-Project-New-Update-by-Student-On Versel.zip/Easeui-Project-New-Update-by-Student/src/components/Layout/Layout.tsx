import React from "react";
import { cva, type VariantProps } from "class-variance-authority";
import { cn } from "@/libs/utils";

// this is NOT the same as HomeLayout/ComponentLayout (those wrap whole pages
// with routing). this Layout is a small reusable piece - like Stack/Grid in
// other UI libraries - for arranging whatever children you give it.

const layoutVariants = cva("w-full", {
  variants: {
    variant: {
      stack: "flex flex-col",
      row: "flex flex-row flex-wrap",
      grid: "grid",
      // "auto-grid", "masonry", and "sidebar" are all handled with their
      // own inline styles / early-return markup below since fixed cva
      // classes can't express them - they're still listed here so
      // TypeScript knows these are valid values for the `variant` prop
      "auto-grid": "grid",
      masonry: "",
      sidebar: "",
    },
    gap: {
      sm: "gap-2",
      md: "gap-4",
      lg: "gap-8",
    },
  },
  defaultVariants: {
    variant: "stack",
    gap: "md",
  },
});

const gapValue = (gap: "sm" | "md" | "lg") =>
  gap === "sm" ? "0.5rem" : gap === "lg" ? "2rem" : "1rem";

export interface LayoutProps extends VariantProps<typeof layoutVariants> {
  children: React.ReactNode;
  // used when variant="grid" - fixed number of columns
  columns?: number;
  // used when variant="auto-grid" - each item is at least this wide,
  // and the browser fits as many columns as will fit on its own,
  // no breakpoints needed at all
  minItemWidth?: string;
  // used when variant="sidebar" - content shown in the side column
  sidebar?: React.ReactNode;
  sidebarWidth?: string;
  className?: string;
}

const Layout = ({
  children,
  variant = "stack",
  gap = "md",
  columns = 3,
  minItemWidth = "220px",
  sidebar,
  sidebarWidth = "16rem",
  className,
}: LayoutProps) => {
  // sidebar mode needs its own markup since it's two independent columns,
  // not something cva alone can express cleanly
  if (variant === "sidebar") {
    return (
      <div
        className={cn("w-full flex flex-col md:flex-row", className)}
        style={{ gap: gapValue(gap ?? "md") }}
      >
        <div style={{ flex: `0 0 ${sidebarWidth}` }} className="shrink-0">
          {sidebar}
        </div>
        <div className="flex-1 min-w-0">{children}</div>
      </div>
    );
  }

  // auto-grid: the trick here is CSS's own auto-fit + minmax combo.
  // "repeat(auto-fit, minmax(220px, 1fr))" tells the browser: fit as many
  // columns of at least 220px as you can, and stretch them evenly to fill
  // the row. shrink the window and columns drop automatically - no
  // @media breakpoints written anywhere for this to work.
  if (variant === "auto-grid") {
    return (
      <div
        className={cn("grid w-full", className)}
        style={{
          gridTemplateColumns: `repeat(auto-fit, minmax(${minItemWidth}, 1fr))`,
          gap: gapValue(gap ?? "md"),
        }}
      >
        {children}
      </div>
    );
  }

  // masonry: this is the Pinterest-style layout where items stack into
  // vertical columns without leaving gaps, even when each item is a
  // different height. CSS grid can't do this on its own (every row locks
  // to the tallest item), so this uses CSS multi-column layout instead -
  // each child naturally flows into the next available column.
  if (variant === "masonry") {
    return (
      <div
        className={cn("w-full", className)}
        style={{
          columnCount: columns,
          columnGap: gapValue(gap ?? "md"),
        }}
      >
        {React.Children.map(children, (child, i) => (
          <div key={i} style={{ breakInside: "avoid", marginBottom: gapValue(gap ?? "md") }}>
            {child}
          </div>
        ))}
      </div>
    );
  }

  return (
    <div
      className={cn(layoutVariants({ variant, gap }), className)}
      style={variant === "grid" ? { gridTemplateColumns: `repeat(${columns}, minmax(0, 1fr))` } : undefined}
    >
      {children}
    </div>
  );
};

Layout.displayName = "Layout";
// eslint-disable-next-line react-refresh/only-export-components
export { Layout, layoutVariants };
