import React, { useState, useRef, useEffect } from "react";
import { ChevronLeft, ChevronRight } from "lucide-react";
import { cn } from "@/libs/utils";
import gsap from "gsap";

export interface CarouselProps {
  slides: React.ReactNode[];
  autoPlay?: boolean;
  interval?: number;
  showDots?: boolean;
  showArrows?: boolean;
  className?: string;
}

const Carousel = ({
  slides,
  autoPlay = false,
  interval = 5000,
  showDots = true,
  showArrows = true,
  className,
}: CarouselProps) => {
  const [index, setIndex] = useState(0);
  const trackRef = useRef<HTMLDivElement | null>(null);
  const progressRef = useRef<HTMLDivElement | null>(null);
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);

  const goTo = React.useCallback(
    (next: number) => {
      const clamped = (next + slides.length) % slides.length;
      setIndex(clamped);
    },
    [slides.length]
  );

  useEffect(() => {
    if (trackRef.current) {
      // xPercent moves relative to the track's OWN width, and the track is
      // slides.length times wider than what we can actually see.
      // so moving one slide forward is only (100 / slides.length)% of the
      // track, not a full 100%. this was the bug making it go blank -
      // it was sliding way past the real slides into empty space.
      gsap.to(trackRef.current, {
        xPercent: (-100 * index) / slides.length,
        duration: 0.7,
        ease: "power3.inOut",
      });
    }
  }, [index, slides.length]);

  useEffect(() => {
    if (!autoPlay) return;
    timerRef.current = setInterval(() => goTo(index + 1), interval);
    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [autoPlay, interval, index, goTo]);

  // little progress bar that fills up while a slide is showing, so people
  // can actually see how much time is left before it auto-advances
  useEffect(() => {
    if (!autoPlay || !progressRef.current) return;
    gsap.fromTo(
      progressRef.current,
      { scaleX: 0 },
      { scaleX: 1, duration: interval / 1000, ease: "none", transformOrigin: "left" }
    );
  }, [index, autoPlay, interval]);

  return (
    <div
      className={cn("relative w-full max-w-2xl overflow-hidden rounded-xl", className)}
      onMouseEnter={() => timerRef.current && clearInterval(timerRef.current)}
    >
      <div className="relative h-64 w-full overflow-hidden">
        <div ref={trackRef} className="flex h-full" style={{ width: `${slides.length * 100}%` }}>
          {slides.map((slide, i) => (
            <div
              key={i}
              className="flex h-full w-full flex-shrink-0 items-center justify-center"
              style={{ width: `${100 / slides.length}%` }}
            >
              {slide}
            </div>
          ))}
        </div>
      </div>

      {showArrows && slides.length > 1 && (
        <>
          <button
            type="button"
            onClick={() => goTo(index - 1)}
            aria-label="Previous slide"
            className="absolute left-2 top-1/2 -translate-y-1/2 rounded-full bg-white/80 p-1.5 shadow hover:bg-white transition-colors"
          >
            <ChevronLeft size={18} />
          </button>
          <button
            type="button"
            onClick={() => goTo(index + 1)}
            aria-label="Next slide"
            className="absolute right-2 top-1/2 -translate-y-1/2 rounded-full bg-white/80 p-1.5 shadow hover:bg-white transition-colors"
          >
            <ChevronRight size={18} />
          </button>
        </>
      )}

      {showDots && slides.length > 1 && (
        <div className="absolute bottom-3 left-1/2 flex -translate-x-1/2 gap-2">
          {slides.map((_, i) => (
            <button
              key={i}
              type="button"
              aria-label={`Go to slide ${i + 1}`}
              onClick={() => goTo(i)}
              className={cn(
                "h-2 w-2 rounded-full transition-all",
                i === index ? "bg-white w-4" : "bg-white/50"
              )}
            />
          ))}
        </div>
      )}

      {autoPlay && (
        <div className="absolute bottom-0 left-0 h-1 w-full bg-white/20">
          <div ref={progressRef} className="h-full w-full bg-white origin-left" />
        </div>
      )}
    </div>
  );
};

Carousel.displayName = "Carousel";
export { Carousel };
