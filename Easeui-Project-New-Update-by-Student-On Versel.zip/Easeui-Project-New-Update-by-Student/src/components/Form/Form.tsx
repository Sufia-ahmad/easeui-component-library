import React, { useState } from "react";
import { cn } from "@/libs/utils";

export type FieldRule = {
  required?: boolean;
  minLength?: number;
  pattern?: RegExp;
  message?: string;
};

export type FormField = {
  name: string;
  label: string;
  type?: "text" | "email" | "password" | "textarea" | "select" | "checkbox";
  placeholder?: string;
  options?: string[]; // used when type === "select"
  rules?: FieldRule;
};

export interface FormProps {
  fields: FormField[];
  submitLabel?: string;
  // called with all field values once every rule passes
  onSubmit?: (values: Record<string, string>) => void;
  // optional - lets the parent reset the form after a successful submit
  resetOnSubmit?: boolean;
  className?: string;
}

function validateField(value: string, rules?: FieldRule): string | null {
  if (!rules) return null;
  if (rules.required && !value.trim()) {
    return rules.message ?? "This field is required.";
  }
  if (rules.minLength && value.length < rules.minLength) {
    return rules.message ?? `Must be at least ${rules.minLength} characters.`;
  }
  if (rules.pattern && value && !rules.pattern.test(value)) {
    return rules.message ?? "Invalid format.";
  }
  return null;
}

const emptyValues = (fields: FormField[]) =>
  Object.fromEntries(fields.map((f) => [f.name, f.type === "checkbox" ? "" : ""]));

const Form = ({
  fields,
  submitLabel = "Submit",
  onSubmit,
  resetOnSubmit = false,
  className,
}: FormProps) => {
  const [values, setValues] = useState<Record<string, string>>(() => emptyValues(fields));
  const [errors, setErrors] = useState<Record<string, string | null>>({});
  const [submitted, setSubmitted] = useState(false);

  const handleChange = (name: string, value: string) => {
    setValues((prev) => ({ ...prev, [name]: value }));
    if (errors[name]) {
      const field = fields.find((f) => f.name === name);
      setErrors((prev) => ({ ...prev, [name]: validateField(value, field?.rules) }));
    }
  };

  const handleBlur = (field: FormField) => {
    setErrors((prev) => ({
      ...prev,
      [field.name]: validateField(values[field.name] ?? "", field.rules),
    }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const nextErrors: Record<string, string | null> = {};
    let hasError = false;
    fields.forEach((f) => {
      const err = validateField(values[f.name] ?? "", f.rules);
      nextErrors[f.name] = err;
      if (err) hasError = true;
    });
    setErrors(nextErrors);
    setSubmitted(true);

    if (!hasError) {
      onSubmit?.(values);
      if (resetOnSubmit) {
        setValues(emptyValues(fields));
        setSubmitted(false);
      }
    }
  };

  return (
    <form onSubmit={handleSubmit} className={cn("flex flex-col gap-4 w-full max-w-md", className)}>
      {fields.map((field) => {
        const error = errors[field.name];
        const inputClasses = cn(
          "w-full rounded-md border px-3 py-2 text-sm transition-colors focus:outline-none focus:ring-1",
          error
            ? "border-red-400 focus:ring-red-400"
            : "border-gray-300 focus:ring-indigo-500"
        );

        // checkbox needs its own layout - label sits next to the box, not above it
        if (field.type === "checkbox") {
          return (
            <div key={field.name} className="flex flex-col gap-1">
              <label htmlFor={field.name} className="flex items-center gap-2 text-sm text-gray-700">
                <input
                  id={field.name}
                  type="checkbox"
                  checked={values[field.name] === "true"}
                  onChange={(e) => handleChange(field.name, e.target.checked ? "true" : "")}
                  className="h-4 w-4 rounded border-gray-300 text-indigo-600 focus:ring-indigo-500"
                />
                {field.label}
              </label>
              {error && <p className="text-xs text-red-500">{error}</p>}
            </div>
          );
        }

        return (
          <div key={field.name} className="flex flex-col gap-1">
            <label htmlFor={field.name} className="text-sm font-medium text-gray-700">
              {field.label}
            </label>

            {field.type === "textarea" && (
              <textarea
                id={field.name}
                placeholder={field.placeholder}
                value={values[field.name]}
                onChange={(e) => handleChange(field.name, e.target.value)}
                onBlur={() => handleBlur(field)}
                className={cn(inputClasses, "min-h-[90px] resize-y")}
              />
            )}

            {field.type === "select" && (
              <select
                id={field.name}
                value={values[field.name]}
                onChange={(e) => handleChange(field.name, e.target.value)}
                onBlur={() => handleBlur(field)}
                className={inputClasses}
              >
                <option value="" disabled>
                  {field.placeholder ?? "Select an option"}
                </option>
                {(field.options ?? []).map((opt) => (
                  <option key={opt} value={opt}>
                    {opt}
                  </option>
                ))}
              </select>
            )}

            {(!field.type ||
              field.type === "text" ||
              field.type === "email" ||
              field.type === "password") && (
              <input
                id={field.name}
                type={field.type ?? "text"}
                placeholder={field.placeholder}
                value={values[field.name]}
                onChange={(e) => handleChange(field.name, e.target.value)}
                onBlur={() => handleBlur(field)}
                className={inputClasses}
              />
            )}

            {error && <p className="text-xs text-red-500">{error}</p>}
          </div>
        );
      })}

      <button
        type="submit"
        className="mt-2 rounded-md bg-indigo-600 px-4 py-2 text-sm font-medium text-white transition-colors hover:bg-indigo-700"
      >
        {submitLabel}
      </button>

      {submitted && Object.values(errors).every((e) => !e) && !resetOnSubmit && (
        <p className="text-sm text-green-600">Form submitted successfully.</p>
      )}
    </form>
  );
};

Form.displayName = "Form";
export { Form };
