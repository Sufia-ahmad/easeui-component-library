import { useState } from "react";
import { Outlet, useLocation, useNavigate } from "react-router";
import { Menu } from "lucide-react";


const ComponentLayout = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const [sidebarOpen, setSidebarOpen] = useState(false);

  const components = [
    { label: "Button", path: "button" },
    { label: "Card", path: "card" },
    { label: "Modal", path: "modal" },
    { label: "Input", path: "input" },
    { label: "Navbar", path: "navbar" },
    { label: "Carousel", path: "carousel" },
    { label: "Tooltip", path: "tooltip" },
    { label: "Color Picker", path: "colorpicker" },
    { label: "Form", path: "form" },
    { label: "3D Effect Card", path: "3dcard" },
    { label: "Layout", path: "layout" },
  ];

  return (
    <div className="flex min-h-screen text-[var(--text-color)]">
      <aside
        className={`
          w-64 p-6 flex flex-col
          bg-[var(--bg-color)]
          border-r border-gray-200 dark:border-gray-800
          fixed md:static top-0 left-0 h-full z-20
          transform ${sidebarOpen ? "translate-x-0" : "-translate-x-full"} 
          transition-transform duration-300 ease-in-out
          md:translate-x-0
        `}
      >
        <h2 className="text-md font-bold mb-6">Components</h2>
        <ul className="flex flex-col gap-2">
          {components.map((item) => (
            <li
              onClick={() => navigate(item.path)}
              key={item.path}
              className={`cursor-pointer hover:text-black dark:hover:text-white text-md hover:translate-x-1 transition-all duration-200 ease-in-out ${
                location.pathname === `/components/${item.path}`
                  ? "text-black dark:text-white"
                  : "text-gray-400 dark:text-gray-500"
              }`}
            >
              {item.label}
            </li>
          ))}
        </ul>
      </aside>

      <div className="flex-1 ml-10 overflow-auto h-screen p-6 bg-[var(--bg-color)]">
        <button
          className="md:hidden mb-4 text-gray-700 dark:text-gray-300"
          onClick={() => setSidebarOpen(!sidebarOpen)}
        >
          <Menu size={24} />
        </button>

        <Outlet />
      </div>
    </div>
  );
};

export default ComponentLayout;
