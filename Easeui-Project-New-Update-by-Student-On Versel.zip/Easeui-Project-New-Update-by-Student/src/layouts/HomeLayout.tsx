import { Outlet } from "react-router";
import Navbar from "../components/Personal/Navbar";


const HomeLayout = () => {
  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />

      <main className="grow p-6">
        <Outlet />
      </main>
    </div>
  );
};

export default HomeLayout;
