import { useState } from "react";
import { Form } from "@/components/Form/Form";
import ComponentDemo from "../ComponentsDemo";
import PropsTable from "@/components/Personal/PropsTable";
import { MessageSquare, Trash2, Volume2 } from "lucide-react";

// what one submitted message looks like once stored
type StoredMessage = {
  id: number;
  name: string;
  email: string;
  topic: string;
  message: string;
  subscribed: boolean;
  time: string;
};

const STORAGE_KEY = "easeui_form_messages";

const FormPage = () => {
  // this is our "message store". saving happens automatically on every
  // submit - straight into localStorage, no limit on how many. reading
  // happens automatically too, right when the page opens.
  const readFromStorage = (): StoredMessage[] => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      return saved ? JSON.parse(saved) : [];
    } catch {
      // if localStorage is blocked or the saved data got corrupted somehow,
      // just start empty instead of crashing the page
      return [];
    }
  };

  const [messages, setMessages] = useState<StoredMessage[]>(readFromStorage);
  const [speakingId, setSpeakingId] = useState<number | null>(null);

  const handleSubmit = (values: Record<string, string>) => {
    const newMessage: StoredMessage = {
      id: Date.now(),
      name: values.name,
      email: values.email,
      topic: values.topic,
      message: values.message,
      subscribed: values.subscribe === "true",
      time: new Date().toLocaleTimeString(),
    };

    // read whatever is already saved and add the new one on top -
    // no cap, keeps every message that's ever been submitted
    const updated = [newMessage, ...readFromStorage()];
    localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
    setMessages(updated);
  };

  const clearMessages = () => {
    setMessages([]);
    localStorage.removeItem(STORAGE_KEY);
    window.speechSynthesis.cancel();
    setSpeakingId(null);
  };

  // this is the "self read" part - clicking a message makes the browser
  // actually speak it out loud, using the built-in Web Speech API.
  // no external library needed, every modern browser has this.
  const speakMessage = (m: StoredMessage) => {
    // stop whatever was being read before, so two messages don't
    // talk over each other
    window.speechSynthesis.cancel();

    if (speakingId === m.id) {
      // clicking the same message again just stops it
      setSpeakingId(null);
      return;
    }

    const textToRead = `Message from ${m.name}, about ${m.topic}. ${m.message}`;
    const utterance = new SpeechSynthesisUtterance(textToRead);

    utterance.onend = () => setSpeakingId(null);
    utterance.onerror = () => setSpeakingId(null);

    setSpeakingId(m.id);
    window.speechSynthesis.speak(utterance);
  };

  const usage = `import { Form } from "@/components/Form/Form";

<Form
  fields={[
    { name: "name", label: "Name", rules: { required: true } },
    { name: "email", label: "Email", type: "email", rules: { required: true, pattern: /^\\S+@\\S+\\.\\S+$/ } },
    { name: "topic", label: "Topic", type: "select", options: ["General", "Support", "Feedback"] },
    { name: "message", label: "Message", type: "textarea", rules: { minLength: 10 } },
    { name: "subscribe", label: "Subscribe to updates", type: "checkbox" },
  ]}
  onSubmit={(values) => {
    // save it wherever you want - here we just push it into a list
  }}
  resetOnSubmit
/>`;

  const propsData = [
    { prop: "fields", type: "FormField[]", default: "-", description: "Field configs: name, label, type, options (for select), and validation rules." },
    { prop: "submitLabel", type: "string", default: `"Submit"`, description: "Text shown on the submit button." },
    { prop: "onSubmit", type: "(values: Record<string, string>) => void", default: "-", description: "Called with all field values once validation passes." },
    { prop: "resetOnSubmit", type: "boolean", default: "false", description: "Clears the form automatically after a successful submit." },
    { prop: "className", type: "string", default: "-", description: "Additional custom class names for the form container." },
  ];

  return (
    <div className="max-w-4xl mx-auto p-4 space-y-12">
      <div className="space-y-4">
        <h1 className="text-4xl font-bold tracking-tight">Form</h1>
        <p className="text-xl text-gray-600">
          A field-config-driven form with validation, a dropdown, a checkbox,
          and a live demo that stores what you submit - click any saved
          message and the browser reads it out loud.
        </p>
      </div>

      <section className="space-y-4">
        <h2 className="text-2xl font-semibold">Usage</h2>
        <ComponentDemo code={usage}>
          <div className="flex flex-col md:flex-row gap-10 w-full">
            <Form
              fields={[
                { name: "name", label: "Name", rules: { required: true } },
                {
                  name: "email",
                  label: "Email",
                  type: "email",
                  rules: {
                    required: true,
                    pattern: /^\S+@\S+\.\S+$/,
                    message: "Enter a valid email.",
                  },
                },
                {
                  name: "topic",
                  label: "Topic",
                  type: "select",
                  options: ["General", "Support", "Feedback"],
                  rules: { required: true, message: "Please pick a topic." },
                },
                {
                  name: "message",
                  label: "Message",
                  type: "textarea",
                  rules: { minLength: 10, message: "Message must be at least 10 characters." },
                },
                { name: "subscribe", label: "Subscribe to updates", type: "checkbox" },
              ]}
              onSubmit={handleSubmit}
              resetOnSubmit
            />

            {/* the "message store" - every submit gets saved to
                localStorage automatically and loads automatically too.
                click any message and the browser reads it out loud. */}
            <div className="flex-1 min-w-0">
              <div className="flex items-center justify-between mb-3">
                <h3 className="flex items-center gap-2 text-sm font-semibold text-gray-700">
                  <MessageSquare size={16} />
                  Stored Messages ({messages.length})
                </h3>
                {messages.length > 0 && (
                  <button
                    type="button"
                    onClick={clearMessages}
                    className="flex items-center gap-1 text-xs text-red-500 hover:text-red-700"
                  >
                    <Trash2 size={12} />
                    Clear
                  </button>
                )}
              </div>

              {messages.length === 0 ? (
                <p className="text-sm text-gray-400">
                  Submit the form to see messages show up here. They save
                  automatically and stick around even after a page refresh.
                </p>
              ) : (
                <ul className="flex flex-col gap-2 max-h-72 overflow-y-auto pr-1">
                  {messages.map((m) => (
                    <li
                      key={m.id}
                      onClick={() => speakMessage(m)}
                      className={`cursor-pointer rounded-md border p-3 text-sm shadow-sm transition-colors ${
                        speakingId === m.id
                          ? "border-indigo-400 bg-indigo-50"
                          : "border-gray-200 bg-white hover:bg-gray-50"
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        <span className="font-medium text-gray-800">{m.name}</span>
                        <span className="flex items-center gap-2 text-xs text-gray-400">
                          <Volume2
                            size={13}
                            className={speakingId === m.id ? "text-indigo-500 animate-pulse" : ""}
                          />
                          {m.time}
                        </span>
                      </div>
                      <p className="text-xs text-gray-500">{m.email} • {m.topic}</p>
                      <p className="mt-1 text-gray-700">{m.message}</p>
                      {m.subscribed && (
                        <span className="mt-1 inline-block text-xs text-indigo-600">
                          ✓ Subscribed to updates
                        </span>
                      )}
                      <p className="mt-1 text-[11px] text-gray-400">
                        {speakingId === m.id ? "Reading aloud… click to stop" : "Click to read aloud"}
                      </p>
                    </li>
                  ))}
                </ul>
              )}
            </div>
          </div>
        </ComponentDemo>
      </section>

      <section className="space-y-4">
        <h2 className="text-2xl font-semibold">API Reference</h2>
        <PropsTable data={propsData} />
      </section>
    </div>
  );
};

export default FormPage;
