import { Carousel } from "@/components/Carousel/Carousel";
import ComponentDemo from "../ComponentsDemo";
import PropsTable from "@/components/Personal/PropsTable";

// A little caption slide - image with a gradient + text overlay
const PhotoSlide = ({ src, title, place }: { src: string; title: string; place: string }) => (
  <div className="relative h-full w-full overflow-hidden">
    <img src={src} alt={title} className="h-full w-full object-cover" />
    <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/10 to-transparent" />
    <div className="absolute bottom-4 left-4 text-white">
      <p className="text-lg font-semibold drop-shadow">{title}</p>
      <p className="text-sm text-white/80 drop-shadow">{place}</p>
    </div>
  </div>
);

const CarouselPage = () => {
  const usage = `import { Carousel } from "@/components/Carousel/Carousel";

<Carousel
  slides={[<PhotoSlide ... />, <PhotoSlide ... />, <PhotoSlide ... />]}
  autoPlay
  interval={5000}
/>`;

  const propsData = [
    { prop: "slides", type: "React.ReactNode[]", default: "-", description: "Array of slide content, one node per slide." },
    { prop: "autoPlay", type: "boolean", default: "false", description: "Automatically advance to the next slide." },
    { prop: "interval", type: "number", default: "5000", description: "Milliseconds each slide stays before auto-advancing." },
    { prop: "showDots", type: "boolean", default: "true", description: "Show clickable pagination dots." },
    { prop: "showArrows", type: "boolean", default: "true", description: "Show previous/next arrow buttons." },
    { prop: "className", type: "string", default: "-", description: "Additional custom class names." },
  ];

  return (
    <div className="max-w-4xl mx-auto p-4 space-y-12">
      <div className="space-y-4">
        <h1 className="text-4xl font-bold tracking-tight">Carousel</h1>
        <p className="text-xl text-gray-600">
          A sliding carousel with arrow navigation, pagination dots, and
          optional auto-play. Each slide now stays visible for 5 seconds
          by default, giving people time to actually read it.
        </p>
      </div>

      <section className="space-y-4">
        <h2 className="text-2xl font-semibold">Usage</h2>
        <ComponentDemo code={usage}>
          <div className="w-full max-w-2xl h-64 rounded-xl overflow-hidden">
            <Carousel
              autoPlay
              interval={5000}
              slides={[
                <PhotoSlide
                  src="https://images.unsplash.com/photo-1506905925346-21bda4d32df4?auto=format&fit=crop&q=80&w=1200"
                  title="Mountain Escape"
                  place="Swiss Alps"
                />,
                <PhotoSlide
                  src="https://images.unsplash.com/photo-1507525428034-b723cf961d3e?auto=format&fit=crop&q=80&w=1200"
                  title="Beach Sunset"
                  place="Bali, Indonesia"
                />,
                <PhotoSlide
                  src="https://images.unsplash.com/photo-1519681393784-d120267933ba?auto=format&fit=crop&q=80&w=1200"
                  title="City Lights"
                  place="Tokyo, Japan"
                />,
                <PhotoSlide
                  src="https://images.unsplash.com/photo-1441974231531-c6227db76b6e?auto=format&fit=crop&q=80&w=1200"
                  title="Forest Trail"
                  place="Pacific Northwest"
                />,
              ]}
            />
          </div>
        </ComponentDemo>
      </section>

      <section className="space-y-4">
        <h2 className="text-2xl font-semibold">API Reference</h2>
        <PropsTable data={propsData} />
      </section>
    </div>
  );
};

export default CarouselPage;
