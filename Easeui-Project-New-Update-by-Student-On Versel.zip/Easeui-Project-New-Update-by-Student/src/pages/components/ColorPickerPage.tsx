import { useState } from "react";
import { ColorPicker } from "@/components/ColorPicker/ColorPicker";
import ComponentDemo from "../ComponentsDemo";
import PropsTable from "@/components/Personal/PropsTable";

const ColorPickerPage = () => {
  const [color, setColor] = useState("#6366f1");

  const usage = `import { ColorPicker } from "@/components/ColorPicker/ColorPicker";

<ColorPicker
  defaultValue="#6366f1"
  onChange={(color) => console.log(color)}
  variant="light"
/>`;

  const propsData = [
    { prop: "value", type: "string", default: "-", description: "Controlled hex color value." },
    { prop: "defaultValue", type: "string", default: `"#6366f1"`, description: "Initial color when uncontrolled." },
    { prop: "onChange", type: "(color: string) => void", default: "-", description: "Called whenever the selected color changes." },
    { prop: "swatches", type: "string[]", default: "15 preset colors", description: "List of quick-pick swatch colors." },
    { prop: "variant", type: `"light" | "dark"`, default: `"light"`, description: "Visual style of the trigger button." },
    { prop: "label", type: "string", default: `"Color"`, description: "Small label shown above the swatch grid." },
    { prop: "className", type: "string", default: "-", description: "Additional custom class names." },
    { prop: "enableVoice", type: "boolean", default: "true", description: "Speak \"Pick me, pick me!\" out loud while the picker is closed, using the browser's SpeechSynthesis API." },
    { prop: "nudgeDelaySec", type: "number", default: "1.5", description: "Seconds between each wiggle + voice nudge cycle while the picker is closed." },
  ];

  return (
    <div className="max-w-4xl mx-auto p-4 space-y-12">
      <div className="space-y-4">
        <h1 className="text-4xl font-bold tracking-tight">Color Picker</h1>
        <p className="text-xl text-gray-600">
          A dropdown color picker with preset swatches, a native color input,
          and a hex text field. While closed, it wiggles and speaks "Pick
          me, pick me!" out loud every 1.5 seconds to grab attention -
          disable this with <code className="text-sm bg-gray-100 px-1 py-0.5 rounded">enableVoice={"{"}false{"}"}</code> if you just want the visual nudge.
        </p>
      </div>

      <section className="space-y-4">
        <h2 className="text-2xl font-semibold">Usage</h2>
        <ComponentDemo code={usage}>
          <ColorPicker value={color} onChange={setColor} />
        </ComponentDemo>
      </section>

      <section className="space-y-4">
        <h2 className="text-2xl font-semibold">API Reference</h2>
        <PropsTable data={propsData} />
      </section>
    </div>
  );
};

export default ColorPickerPage;
