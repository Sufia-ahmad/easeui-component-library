import { Card3D } from "@/components/Card3D/Card3D";
import ComponentDemo from "../ComponentsDemo";
import PropsTable from "@/components/Personal/PropsTable";

const Card3DPage = () => {
  const usage = `import { Card3D } from "@/components/Card3D/Card3D";

<Card3D
  title="Mountain Escape"
  description="Explore the untouched peaks."
  image="..."
  size="md"
  back={<p>Trip length: 5 days • From $999</p>}
/>`;

  const propsData = [
    { prop: "title", type: "string", default: "-", description: "Title displayed at the bottom of the card." },
    { prop: "description", type: "string", default: "-", description: "Supporting text below the title." },
    { prop: "image", type: "string", default: "-", description: "Background image URL for the front face." },
    { prop: "variant", type: `"light" | "dark"`, default: `"light"`, description: "Base color theme, also used for the back face." },
    { prop: "size", type: `"sm" | "md" | "lg"`, default: `"md"`, description: "Card dimensions." },
    { prop: "maxTilt", type: "number", default: "12", description: "Maximum tilt angle in degrees as the pointer moves." },
    { prop: "back", type: "React.ReactNode", default: "-", description: "If given, clicking the card flips it over to reveal this content." },
    { prop: "className", type: "string", default: "-", description: "Additional custom class names." },
  ];

  return (
    <div className="max-w-4xl mx-auto p-4 space-y-12">
      <div className="space-y-4">
        <h1 className="text-4xl font-bold tracking-tight">3D Effect Card</h1>
        <p className="text-xl text-gray-600">
          Move your mouse over the card to feel it tilt with a holographic
          shine following the cursor - then click it to flip and see the
          back side.
        </p>
      </div>

      <section className="space-y-4">
        <h2 className="text-2xl font-semibold">Usage</h2>
        <ComponentDemo code={usage}>
          <Card3D
            title="Mountain Escape"
            description="Explore the untouched peaks."
            image="https://images.unsplash.com/photo-1506905925346-21bda4d32df4?auto=format&fit=crop&q=80&w=800"
            size="md"
            back={
              <div className="p-4 space-y-2">
                <p className="text-lg font-semibold">Trip Details</p>
                <p className="text-sm text-gray-500">5 days • Guided trek</p>
                <p className="text-2xl font-bold text-indigo-600">$999</p>
              </div>
            }
          />
        </ComponentDemo>
      </section>

      <section className="space-y-4">
        <h2 className="text-2xl font-semibold">API Reference</h2>
        <PropsTable data={propsData} />
      </section>
    </div>
  );
};

export default Card3DPage;
