import { Tooltip } from "@/components/Tooltip/Tooltip";
import { Button } from "@/components/Button/Button";
import ComponentDemo from "../ComponentsDemo";
import PropsTable from "@/components/Personal/PropsTable";

const TooltipPage = () => {
  const basicUsageCode = `
import { Tooltip } from "@/components/Tooltip/Tooltip"

<Tooltip text="Hello there!" variant="dark" position="top">
  <Button variant="primary" size="sm">Hover me</Button>
</Tooltip>
<Tooltip text="I'm below now" variant="light" position="bottom">
  <Button variant="outline" size="sm">Hover me too</Button>
</Tooltip>`;

  const propsData = [
    {
      prop: "text",
      type: "string",
      default: "-",
      description: "The text shown inside the tooltip",
    },
    {
      prop: "variant",
      type: '"dark" | "light"',
      default: '"dark"',
      description: "The visual style of the tooltip",
    },
    {
      prop: "position",
      type: '"top" | "bottom"',
      default: '"top"',
      description: "Where the tooltip shows up relative to its child",
    },
  ];

  return (
    <div className="max-w-4xl mx-auto p-6 space-y-12">
      <header className="space-y-2">
        <p
          className="text-4xl font-bold tracking-tight"
          style={{ color: "var(--text-color)" }}
        >
          Tooltip
        </p>
        <p className="text-lg text-gray-600">
          Shows a small label with more info when you hover over something.
        </p>
      </header>

      <section className="space-y-4">
        <h2 className="text-2xl font-semibold">Usage</h2>
        <ComponentDemo code={basicUsageCode}>
          <div className="flex gap-6 flex-wrap">
            <Tooltip text="Hello there!" variant="dark" position="top">
              <Button variant="primary" size="sm">
                Hover me
              </Button>
            </Tooltip>
            <Tooltip text="I'm below now" variant="light" position="bottom">
              <Button variant="outline" size="sm">
                Hover me too
              </Button>
            </Tooltip>
          </div>
        </ComponentDemo>
      </section>

      <section className="space-y-4">
        <h2 className="text-2xl font-semibold">API Reference</h2>
        <PropsTable data={propsData} />
      </section>
    </div>
  );
};

export default TooltipPage;
