import { Layout } from "@/components/Layout/Layout";
import ComponentDemo from "../ComponentsDemo";
import PropsTable from "@/components/Personal/PropsTable";

// a plain colored box, just so we can see how children get arranged
const Box = ({ label, tall = false }: { label: string; tall?: boolean }) => (
  <div
    className={`rounded-md bg-indigo-100 text-indigo-700 text-sm font-medium px-4 flex items-center justify-center text-center ${
      tall ? "py-16" : "py-6"
    }`}
  >
    {label}
  </div>
);

const LayoutPage = () => {
  const stackUsage = `<Layout variant="stack" gap="md">
  <Box label="One" />
  <Box label="Two" />
  <Box label="Three" />
</Layout>`;

  const rowUsage = `<Layout variant="row" gap="md">
  <Box label="One" />
  <Box label="Two" />
  <Box label="Three" />
</Layout>`;

  const gridUsage = `<Layout variant="grid" columns={3} gap="md">
  <Box label="1" /> <Box label="2" /> <Box label="3" />
  <Box label="4" /> <Box label="5" /> <Box label="6" />
</Layout>`;

  const autoGridUsage = `// no breakpoints written anywhere - the browser
// fits as many 180px+ columns as the space allows
<Layout variant="auto-grid" minItemWidth="180px" gap="md">
  <Box label="1" /> <Box label="2" /> <Box label="3" />
  <Box label="4" /> <Box label="5" /> <Box label="6" />
</Layout>`;

  const masonryUsage = `// pinterest style - items of different heights
// stack into columns without leaving gaps
<Layout variant="masonry" columns={3} gap="md">
  <Box label="Short" />
  <Box label="Tall" tall />
  <Box label="Short" />
  ...
</Layout>`;

  const sidebarUsage = `<Layout
  variant="sidebar"
  sidebarWidth="10rem"
  sidebar={<Box label="Sidebar" />}
>
  <Box label="Main content area" />
</Layout>`;

  const propsData = [
    { prop: "variant", type: `"stack" | "row" | "grid" | "auto-grid" | "masonry" | "sidebar"`, default: `"stack"`, description: "How children are arranged." },
    { prop: "gap", type: `"sm" | "md" | "lg"`, default: `"md"`, description: "Spacing between children." },
    { prop: "columns", type: "number", default: "3", description: "Column count - used by \"grid\" and \"masonry\"." },
    { prop: "minItemWidth", type: "string", default: `"220px"`, description: "Minimum width per item - used by \"auto-grid\" to decide how many columns fit." },
    { prop: "sidebar", type: "React.ReactNode", default: "-", description: "Side column content, only used when variant is \"sidebar\"." },
    { prop: "sidebarWidth", type: "string", default: `"16rem"`, description: "Width of the sidebar column." },
    { prop: "className", type: "string", default: "-", description: "Additional custom class names." },
  ];

  return (
    <div className="max-w-4xl mx-auto p-4 space-y-12">
      <div className="space-y-4">
        <h1 className="text-4xl font-bold tracking-tight">Layout</h1>
        <p className="text-xl text-gray-600">
          A small reusable component for arranging content - stack it
          vertically, lay it out in a row, put it in a grid, let it
          auto-fit itself responsively, arrange it Pinterest-style, or
          split it into a sidebar + main area. Not to be confused with the
          page-level layouts this app itself uses for routing.
        </p>
      </div>

      <section className="space-y-4">
        <h2 className="text-2xl font-semibold">Stack</h2>
        <ComponentDemo code={stackUsage}>
          <div className="w-full max-w-sm">
            <Layout variant="stack" gap="md">
              <Box label="One" />
              <Box label="Two" />
              <Box label="Three" />
            </Layout>
          </div>
        </ComponentDemo>
      </section>

      <section className="space-y-4">
        <h2 className="text-2xl font-semibold">Row</h2>
        <ComponentDemo code={rowUsage}>
          <div className="w-full">
            <Layout variant="row" gap="md">
              <Box label="One" />
              <Box label="Two" />
              <Box label="Three" />
            </Layout>
          </div>
        </ComponentDemo>
      </section>

      <section className="space-y-4">
        <h2 className="text-2xl font-semibold">Grid</h2>
        <ComponentDemo code={gridUsage}>
          <div className="w-full">
            <Layout variant="grid" columns={3} gap="md">
              <Box label="1" />
              <Box label="2" />
              <Box label="3" />
              <Box label="4" />
              <Box label="5" />
              <Box label="6" />
            </Layout>
          </div>
        </ComponentDemo>
      </section>

      <section className="space-y-4">
        <h2 className="text-2xl font-semibold">Auto Grid (responsive without breakpoints)</h2>
        <p className="text-sm text-gray-500">
          Uses CSS <code className="text-xs bg-gray-100 px-1 py-0.5 rounded">auto-fit</code> +{" "}
          <code className="text-xs bg-gray-100 px-1 py-0.5 rounded">minmax()</code> so the number
          of columns adjusts automatically as the container resizes - no
          media queries needed. Try shrinking your browser window.
        </p>
        <ComponentDemo code={autoGridUsage}>
          <div className="w-full">
            <Layout variant="auto-grid" minItemWidth="140px" gap="md">
              <Box label="1" />
              <Box label="2" />
              <Box label="3" />
              <Box label="4" />
              <Box label="5" />
              <Box label="6" />
            </Layout>
          </div>
        </ComponentDemo>
      </section>

      <section className="space-y-4">
        <h2 className="text-2xl font-semibold">Masonry</h2>
        <p className="text-sm text-gray-500">
          Uses CSS multi-column layout so items of different heights stack
          into columns without leaving gaps - the classic Pinterest look.
          A regular grid can't do this since every row locks to its tallest item.
        </p>
        <ComponentDemo code={masonryUsage}>
          <div className="w-full">
            <Layout variant="masonry" columns={3} gap="md">
              <Box label="Short" />
              <Box label="Tall" tall />
              <Box label="Short" />
              <Box label="Tall" tall />
              <Box label="Short" />
              <Box label="Short" />
            </Layout>
          </div>
        </ComponentDemo>
      </section>

      <section className="space-y-4">
        <h2 className="text-2xl font-semibold">Sidebar</h2>
        <ComponentDemo code={sidebarUsage}>
          <div className="w-full">
            <Layout variant="sidebar" sidebarWidth="10rem" sidebar={<Box label="Sidebar" />}>
              <Box label="Main content area" />
            </Layout>
          </div>
        </ComponentDemo>
      </section>

      <section className="space-y-4">
        <h2 className="text-2xl font-semibold">API Reference</h2>
        <PropsTable data={propsData} />
      </section>
    </div>
  );
};

export default LayoutPage;

