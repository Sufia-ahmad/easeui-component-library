import AppRouter from "./router/AppRouter";


function App() {
  return (
    <div className="min-h-screen w-full">
      <AppRouter />
    </div>
  );
}

export default App;
