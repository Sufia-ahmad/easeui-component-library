import { createBrowserRouter, RouterProvider } from "react-router";
import HomeLayout from "../layouts/HomeLayout";
import ComponentLayout from "../layouts/ComponentLayout";
import HomePage from "../pages/HomePage";
import ButtonPage from "../pages/components/ButtonPage";
import CardPage from "@/pages/components/CardPage";
import ModalPage from "@/pages/components/ModalPage";
import InputPage from "@/pages/components/InputPage";
import NavbarPage from "@/pages/components/NavbarPage";
import TooltipPage from "@/pages/components/TooltipPage";
import ColorPickerPage from "@/pages/components/ColorPickerPage";
import FormPage from "@/pages/components/FormPage";
import Card3DPage from "@/pages/components/Card3DPage";
import CarouselPage from "@/pages/components/CarouselPage";
import LayoutPage from "@/pages/components/LayoutPage";


const AppRouter = () => {
  const router = createBrowserRouter([
    {
      path: "/",
      element: <HomeLayout />,
      children: [
        {
          index: true,
          element: <HomePage />,
        },
        {
          path: "components",
          element: <ComponentLayout />,
          children: [
            {
              path: "button",
              element: <ButtonPage />,
            },
            {
              path: "card",
              element: <CardPage />,
            },
            {
              path: "modal",
              element: <ModalPage />,
            },
            {
              path: "input",
              element: <InputPage />,
            },
            {
              path: "navbar",
              element: <NavbarPage />,
            },
            {
              path: "tooltip",
              element: <TooltipPage />,
            },
            {
              path: "colorpicker",
              element: <ColorPickerPage />,
            },
            {
              path: "form",
              element: <FormPage />,
            },
            {
              path: "3dcard",
              element: <Card3DPage />,
            },
            {
              path: "carousel",
              element: <CarouselPage />,
            },
            {
              path: "layout",
              element: <LayoutPage />,
            },
          ],
        },
      ],
    },
  ]);

  return <RouterProvider router={router} />;
};

export default AppRouter;
