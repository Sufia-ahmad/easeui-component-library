import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import tailwindcss from "@tailwindcss/vite";
import path from "path";

// two build modes:
// - default/"lib" mode: builds the npm-publishable component library
//   bundle (easeui.es.js / easeui.umd.js), no index.html - this is
//   what `npm run build` has always done, unchanged.
// - "app" mode (`vite build --mode app`): builds the actual demo/docs
//   website as a normal SPA with index.html - this is what you deploy
//   to Vercel/Netlify/etc, since the library bundle alone isn't a
//   browsable site.
export default defineConfig(({ mode }) => {
  const isAppBuild = mode === "app";

  return {
    plugins: [react(), tailwindcss()],
    resolve: {
      alias: {
        "@": path.resolve(__dirname, "./src"),
      },
    },
    build: isAppBuild
      ? {
          outDir: "dist-app",
        }
      : {
          lib: {
            entry: path.resolve(__dirname, "src/index.ts"),
            name: "EaseUI",
            fileName: (format) => `easeui.${format}.js`,
          },
          cssCodeSplit: true,
          rollupOptions: {
            external: ["react", "react-dom"],
            output: {
              globals: {
                react: "React",
                "react-dom": "ReactDOM",
              },
            },
          },
        },
  };
});
